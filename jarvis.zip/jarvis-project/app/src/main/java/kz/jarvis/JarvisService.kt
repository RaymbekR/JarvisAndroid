package kz.jarvis

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.telephony.SmsManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/**
 * Jarvis: қолы жоқ / көзі көрмейтін адамдарға арналған дауыстық көмекші.
 * AccessibilityService жүйе қосылған кезде өзі іске қосылады -> "Қош келдіңіз" айтады.
 */
class JarvisService : AccessibilityService(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private val main = Handler(Looper.getMainLooper())
    private var ttsReady = false
    private var speaking = false
    private var awaitingCommand = false
    private val wakeWords = listOf("жарвис", "джарвис", "джарвіс", "jarvis", "жарвис", "ярвис")

    override fun onServiceConnected() {
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        val kk = Locale("kk", "KZ")
        val r = tts.setLanguage(kk)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.language = Locale("ru", "RU") // қазақ дауысы жоқ болса орысша
        }
        ttsReady = true
        speak("Қош келдіңіз. Мен Жарвиспін. Тыңдап тұрмын.") { startListening() }
    }

    // ---------- Сөйлеу ----------
    private fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (!ttsReady) return
        speaking = true
        recognizer?.cancel()
        val id = System.nanoTime().toString()
        tts.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(u: String?) {}
            override fun onError(u: String?) { speaking = false; main.post { onDone?.invoke() } }
            override fun onDone(u: String?) { speaking = false; main.post { onDone?.invoke() } }
        })
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    // ---------- Тыңдау ----------
    private fun startListening() {
        if (speaking) return
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer!!.setRecognitionListener(listener)
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "kk-KZ")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer!!.startListening(i)
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text.isNullOrBlank()) { restart(); return }
            handle(text.lowercase(Locale.ROOT).trim())
        }
        override fun onError(error: Int) { restart() }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun restart(delay: Long = 400) {
        main.postDelayed({ if (!speaking) startListening() }, delay)
    }

    // ---------- Команданы өңдеу ----------
    private fun handle(raw: String) {
        var text = raw
        val wake = wakeWords.firstOrNull { text.contains(it) }
        if (wake != null) {
            text = text.substringAfter(wake).trim(' ', ',', '.')
            if (text.isEmpty()) { awaitingCommand = true; speak("Тыңдап тұрмын") { startListening() }; return }
        } else if (!awaitingCommand) { restart(); return }
        awaitingCommand = false
        execute(text)
    }

    private fun reply(msg: String) = speak(msg) { startListening() }

    private fun execute(t: String) {
        when {
            // "хабарлама жаз Айгүл сәлем қалайсың" / "Айгүлге сәлем деп хабарлама жаз"
            t.contains("хабарлама") || t.contains("смс") || t.startsWith("напиши") -> sendMessage(t)
            t.startsWith("қоңырау шал") || t.startsWith("позвони") || t.contains("қоңырау шал") -> call(t)
            t.startsWith("аш ") || t.startsWith("ашу ") || t.startsWith("открой ") || t.startsWith("open ") ->
                openApp(t.substringAfter(" ").trim())
            t.contains("артқа") || t.contains("назад") -> { performGlobalAction(GLOBAL_ACTION_BACK); reply("Артқа қайттым") }
            t.contains("басты экран") || t.contains("домой") -> { performGlobalAction(GLOBAL_ACTION_HOME); reply("Басты экран") }
            t.contains("соңғы қолданба") || t.contains("недавние") -> { performGlobalAction(GLOBAL_ACTION_RECENTS); reply("Соңғы қолданбалар") }
            t.contains("төмен") || t.contains("вниз") -> { swipe(up = true); reply("Төмен айналдырдым") }
            t.contains("жоғары") || t.contains("вверх") -> { swipe(up = false); reply("Жоғары айналдырдым") }
            t.contains("экранды оқы") || t.contains("прочитай экран") -> readScreen()
            t.startsWith("бас ") || t.startsWith("түрт ") || t.startsWith("нажми ") -> clickText(t.substringAfter(" ").trim())
            t.startsWith("жаз ") || t.startsWith("введи ") -> typeText(t.substringAfter(" ").trim())
            t.contains("уақыт") || t.contains("сағат нешеде") -> {
                val c = java.util.Calendar.getInstance()
                reply("Сағат ${c.get(java.util.Calendar.HOUR_OF_DAY)} ${c.get(java.util.Calendar.MINUTE)}")
            }
            else -> reply("Түсінбедім. Қайталап айтыңыз.")
        }
    }

    // ---------- Қолданба ашу ----------
    private fun openApp(name: String) {
        val pm = packageManager
        val apps = pm.getInstalledApplications(0)
        val app = apps.firstOrNull {
            val label = pm.getApplicationLabel(it).toString().lowercase()
            label.contains(name) || name.contains(label)
        }
        val launch = app?.let { pm.getLaunchIntentForPackage(it.packageName) }
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launch)
            reply("$name ашылды")
        } else reply("$name қолданбасы табылмады")
    }

    // ---------- Контакт / SMS / қоңырау ----------
    private fun findContact(nameQuery: String): Pair<String, String>? {
        val cur = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        ) ?: return null
        cur.use {
            while (it.moveToNext()) {
                val n = it.getString(0)?.lowercase() ?: continue
                // қосымшаларды (ға/ге/қа/ке/на) елемеу үшін префикс бойынша салыстыру
                if (n.contains(nameQuery) || nameQuery.startsWith(n.take(maxOf(3, n.length - 2)))) {
                    return n to it.getString(1)
                }
            }
        }
        return null
    }

    private fun sendMessage(t: String) {
        // "<аты> <мәтін> деп хабарлама жаз"  немесе  "хабарлама жаз <аты> <мәтін>"
        val body = t.replace(Regex("\\s*деп\\s+(хабарлама|смс)\\s*(жаз|жібер)?"), "")
            .replace(Regex("^(хабарлама|смс|напиши)\\s*(жаз|жібер)?\\s*"), "").trim()
        val parts = body.split(" ", limit = 2)
        if (parts.size < 2) { reply("Кімге және не жазу керек?"); return }
        val contact = findContact(parts[0])
        if (contact == null) { reply("${parts[0]} контактілерде табылмады"); return }
        try {
            SmsManager.getDefault().sendTextMessage(contact.second, null, parts[1], null, null)
            reply("${contact.first} адамына хабарлама жіберілді: ${parts[1]}")
        } catch (e: Exception) { reply("Хабарлама жіберілмеді") }
    }

    private fun call(t: String) {
        val q = t.replace("қоңырау шал", "").replace("позвони", "").trim()
        val c = findContact(q)
        if (c == null) { reply("Контакт табылмады"); return }
        val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:${c.second}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        reply("${c.first} адамына қоңырау шалып жатырмын")
    }

    // ---------- Экранмен жұмыс ----------
    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<String>) {
        if (node == null) return
        val s = node.text?.toString() ?: node.contentDescription?.toString()
        if (!s.isNullOrBlank()) out.add(s)
        for (i in 0 until node.childCount) collect(node.getChild(i), out)
    }

    private fun readScreen() {
        val list = mutableListOf<String>()
        collect(rootInActiveWindow, list)
        reply(if (list.isEmpty()) "Экранда мәтін жоқ" else list.take(25).joinToString(". "))
    }

    private fun findByText(node: AccessibilityNodeInfo?, q: String): AccessibilityNodeInfo? {
        if (node == null) return null
        val s = (node.text ?: node.contentDescription)?.toString()?.lowercase()
        if (s != null && s.contains(q)) return node
        for (i in 0 until node.childCount) findByText(node.getChild(i), q)?.let { return it }
        return null
    }

    private fun clickText(q: String) {
        var n = findByText(rootInActiveWindow, q)
        while (n != null && !n.isClickable) n = n.parent
        if (n != null) { n.performAction(AccessibilityNodeInfo.ACTION_CLICK); reply("$q басылды") }
        else reply("$q экраннан табылмады")
    }

    private fun typeText(text: String) {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (f == null) { reply("Жазатын өріс таңдалмаған"); return }
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        reply("Жазылды: $text")
    }

    private fun swipe(up: Boolean) {
        val m = resources.displayMetrics
        val x = m.widthPixels / 2f
        val (y1, y2) = if (up) m.heightPixels * 0.7f to m.heightPixels * 0.3f
        else m.heightPixels * 0.3f to m.heightPixels * 0.7f
        val p = Path().apply { moveTo(x, y1); lineTo(x, y2) }
        dispatchGesture(
            GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build(),
            null, null
        )
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { tts.stop() }
    override fun onDestroy() {
        recognizer?.destroy(); tts.shutdown(); super.onDestroy()
    }
}
