package kz.jarvis

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

/** Бір реттік баптау экраны (көмекшісі бар адам жасайды). */
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
                Manifest.permission.SEND_SMS, Manifest.permission.CALL_PHONE
            ), 1
        )
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        layout.addView(TextView(this).apply {
            text = "Jarvis баптау:\n1) Барлық рұқсаттарды беріңіз.\n2) Төмендегі батырма арқылы Арнайы мүмкіндіктер -> Jarvis қызметін қосыңыз."
            textSize = 18f
        })
        layout.addView(Button(this).apply {
            text = "Арнайы мүмкіндіктерді ашу"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(layout)
    }
}
